"""
BẢN RIÊNG của modal_ocr_encode.py, CHỈ dùng cho dataset video MỚI (xem
modal_keyframe_extract_gpu.py + HUONG_DAN_DATASET_MOI_4_THANH_VIEN.md) — đọc keyframe từ Volume
RIÊNG "aic2026-newdataset" (KHÔNG phải "aic2026-keyframes" của dataset L21-L30 cũ) và tải kết quả
OCR về thư mục local RIÊNG data_newdataset/processed/ocr_text/ (KHÔNG phải data/processed/ocr_text/
cũ). Tách hẳn file này ra thay vì thêm cờ vào modal_ocr_encode.py để dataset cũ và dataset mới
KHÔNG BAO GIỜ lẫn/đè kết quả OCR lên nhau, dù chạy nhầm lệnh.

Muốn dùng dataset MỚI cho search thật (build FAISS/BM25 + serve UI), CHỦ ĐỘNG gộp thủ công
data_newdataset/ vào data/ sau khi đã kiểm tra kỹ — xem HUONG_DAN_DATASET_MOI_4_THANH_VIEN.md.

Cùng model/logic/schema với indexing/ocr/run_ocr.py (PP-OCRv6 + VietOCR fallback) — chỉ khác NƠI
CHẠY (GPU Modal) và NƠI ĐỌC/GHI (Volume + thư mục local riêng cho dataset mới). Không dùng Drive/
rclone — dataset mới đi thẳng qua Volume "aic2026-newdataset" (ghi bởi modal_keyframe_extract_gpu.py).

CHUẨN BỊ: đã chạy modal_keyframe_extract_gpu.py trước (Volume "aic2026-newdataset" đã có keyframe).

CÁCH DÙNG (chạy trong thư mục gốc repo aic2026-project):
    modal run modal_ocr_encode_newdataset.py --from-volume

    # Chỉ 1 video cụ thể:
    modal run modal_ocr_encode_newdataset.py --from-volume --video-id N005

GPU: mặc định "L40S" (đủ VRAM cho PP-OCRv6 + VietOCR chạy song song). Đổi GPU_TYPE bên dưới nếu
muốn rẻ hơn/nhanh hơn — xem modal.com/pricing.
"""
import json
import sys
from pathlib import Path

import modal

APP_NAME = "aic2026-ocr-paddle-newdataset"
GPU_TYPE = "L40S"

VOLUME_NAME = "aic2026-newdataset"  # RIÊNG, xem docstring đầu file
VOLUME_MOUNT = "/data_new"
KEYFRAMES_SUBDIR = "keyframes"
OCR_SUBDIR = "processed/ocr_text"

LOCAL_ROOT = Path(__file__).resolve().parent
LOCAL_OCR_DIR = LOCAL_ROOT / "data_newdataset" / "processed" / "ocr_text"
LOCAL_OCR_MODULE_DIR = LOCAL_ROOT / "indexing" / "ocr"  # mount thẳng vào container — TÁI SỬ DỤNG
# nguyên xi logic run_ocr.py (không copy/duplicate), giống hệt modal_ocr_encode.py gốc.

app = modal.App(APP_NAME)
volume = modal.Volume.from_name(VOLUME_NAME, create_if_missing=True)

image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("curl", "unzip", "libgl1", "libglib2.0-0")
    .run_commands(
        # xem lý do pin cu126 + link riêng trong modal_ocr_encode.py (bản gốc)
        "python -m pip install paddlepaddle-gpu==3.3.0 "
        "-i https://www.paddlepaddle.org.cn/packages/stable/cu126/"
    )
    .pip_install(
        "paddleocr>=3.0",
        "vietocr",
        "easyocr",
        "torch",
        "torchvision",
        "pillow",
        "pyyaml",
        "tqdm",
        "opencv-python-headless",
    )
    .add_local_dir(str(LOCAL_OCR_MODULE_DIR), remote_path="/root/ocr")
)


def read_pipeline_config_text() -> str:
    with open(LOCAL_ROOT / "configs" / "pipeline_config.yaml", "r", encoding="utf-8") as f:
        return f.read()


@app.function(image=image, timeout=60)
def parse_ocr_config(yaml_text: str) -> dict:
    import yaml

    cfg = yaml.safe_load(yaml_text)
    return cfg["ocr"]


@app.function(image=image, volumes={VOLUME_MOUNT: volume}, timeout=5 * 60)
def list_volume_video_ids() -> list:
    """Liệt kê MỌI video_id đã có sẵn keyframe (frame_index.json) trên Volume
    'aic2026-newdataset' — ghi bởi modal_keyframe_extract_gpu.py."""
    volume.reload()
    base = Path(VOLUME_MOUNT) / KEYFRAMES_SUBDIR
    if not base.exists():
        return []
    video_ids = sorted(
        p.name for p in base.iterdir() if p.is_dir() and (p / "frame_index.json").exists()
    )
    print(f"[Modal] Tìm thấy {len(video_ids)} video có sẵn keyframe trên Volume '{VOLUME_NAME}'.")
    return video_ids


@app.cls(
    image=image,
    gpu=GPU_TYPE,
    volumes={VOLUME_MOUNT: volume},
    timeout=60 * 60,
    scaledown_window=120,
)
class OCRRunner:
    @modal.enter()
    def setup(self):
        sys.path.insert(0, "/root/ocr")
        import run_ocr as _run_ocr

        self._run_ocr = _run_ocr
        self._engine_name = None
        self._run_engine = None
        self._vietocr_recognize = None

    @modal.method()
    def run_ocr_video(self, video_id: str, cfg_ocr: dict) -> dict:
        if self._engine_name is None:
            cfg_load = dict(cfg_ocr)
            cfg_load["device"] = "gpu:0"
            vcfg = dict(cfg_load.get("vietocr", {}) or {})
            vcfg["use_gpu"] = True
            cfg_load["vietocr"] = vcfg
            self._engine_name, self._run_engine = self._run_ocr.load_ocr_engine(cfg_load)
            self._vietocr_recognize = self._run_ocr.load_vietocr_recognizer(cfg_load)
            self._loaded_cfg_ocr = cfg_load

        volume.reload()

        records = self._run_ocr.run_ocr_for_video(
            video_id,
            str(Path(VOLUME_MOUNT) / KEYFRAMES_SUBDIR),
            self._run_engine,
            self._engine_name,
            self._loaded_cfg_ocr,
            self._vietocr_recognize,
        )

        out_dir = Path(VOLUME_MOUNT) / OCR_SUBDIR
        out_dir.mkdir(parents=True, exist_ok=True)
        with open(out_dir / f"{video_id}.json", "w", encoding="utf-8") as f:
            json.dump(records, f, ensure_ascii=False, indent=2)
        volume.commit()

        n_flagged = sum(1 for r in records if r.get("needs_verification"))
        print(f"[Modal] [{video_id}] {len(records)} đoạn text OCR, {n_flagged} cần xác minh -> đã ghi vào Volume.")
        return {"video_id": video_id, "n_records": len(records), "n_flagged": n_flagged}


def _download_result(video_id: str) -> bool:
    LOCAL_OCR_DIR.mkdir(parents=True, exist_ok=True)
    remote_path = f"/{OCR_SUBDIR}/{video_id}.json"
    try:
        data = b"".join(chunk for chunk in volume.read_file(remote_path))
    except FileNotFoundError:
        print(f"  !!! Không thấy {remote_path} trên Volume — OCR có thể đã lỗi.")
        return False
    (LOCAL_OCR_DIR / f"{video_id}.json").write_bytes(data)
    return True


@app.local_entrypoint()
def main(from_volume: bool = False, video_id: str = ""):
    if not from_volume:
        print(
            "Cần cờ --from-volume (file này CHỈ hỗ trợ đọc keyframe từ Volume "
            "'aic2026-newdataset' — đã trích bằng modal_keyframe_extract_gpu.py)."
        )
        sys.exit(1)

    print("Đang liệt kê video đã có sẵn keyframe trên Volume...")
    video_ids = list_volume_video_ids.remote()
    if not video_ids:
        print("Volume chưa có video nào — chạy modal_keyframe_extract_gpu.py trước.")
        sys.exit(1)
    if video_id:
        if video_id not in video_ids:
            print(f"Volume không có video '{video_id}'.")
            sys.exit(1)
        video_ids = [video_id]

    pending, n_skipped = [], 0
    for vid in video_ids:
        if (LOCAL_OCR_DIR / f"{vid}.json").exists():
            n_skipped += 1
        else:
            pending.append(vid)
    print(f"{len(pending)}/{len(video_ids)} video cần OCR ({n_skipped} đã có kết quả sẵn — bỏ qua).")
    if not pending:
        print("Không còn gì để làm.")
        return

    print(f"\n=== OCR {len(pending)} video trên GPU Modal ({GPU_TYPE}) ===")
    cfg_ocr = parse_ocr_config.remote(read_pipeline_config_text())
    runner = OCRRunner()
    n_ok, n_fail = 0, 0
    for vid in pending:
        print(f"[{vid}] Đang OCR...")
        try:
            result = runner.run_ocr_video.remote(vid, cfg_ocr)
        except Exception as e:
            print(f"[{vid}] !!! LỖI khi OCR: {e}")
            n_fail += 1
            continue
        print(f"[{vid}] Xong: {result['n_records']} đoạn text, {result['n_flagged']} cần xác minh")
        if _download_result(vid):
            print(f"[{vid}] Đã lưu vào {LOCAL_OCR_DIR}/")
            n_ok += 1
        else:
            n_fail += 1

    print(f"\nHoàn tất: {n_ok} video mới OCR, {n_skipped} bỏ qua (đã có sẵn), {n_fail} lỗi.")
