"""
Trích keyframe (method transnetv2_similarity — xem indexing/keyframe_extraction.py) BẰNG GPU thuê
theo giây qua Modal, cho dataset video MỚI (Video_S01.zip + Video_N001-N010.zip ... N091-N100.zip,
nguồn https://aic-data.ledo.io.vn) — chia sẵn cho 4 THÀNH VIÊN chạy song song, mỗi người phụ trách
1 phần riêng (xem MEMBER_FILES bên dưới).

TOÀN BỘ dataset MỚI này ghi vào **Volume RIÊNG "aic2026-newdataset"** — KHÔNG dùng chung Volume
"aic2026-raw-videos"/"aic2026-keyframes" của dataset L21-L30 cũ, để tránh lẫn/đè lên vector-keyframe
cũ đã có sẵn (theo yêu cầu tách riêng). Muốn gộp 2 dataset lại thành 1 hệ tìm kiếm thì làm ở bước
SAU CÙNG, thủ công, sau khi đã kiểm tra kỹ (xem HUONG_DAN_DATASET_MOI_4_THANH_VIEN.md).

LUỒNG XỬ LÝ — 2 PHA (cùng triết lý tách pha với modal_semantic_encode.py/modal_ocr_encode.py, để
phần tải video KHÔNG đụng GPU, tránh trả tiền GPU trong lúc chờ mạng):
    PHA 1 (CPU, rẻ) — với MỖI file zip được giao: tải qua aria2 (đa luồng) + giải nén + gom video
    gốc vào Volume "aic2026-newdataset" (thư mục con "raw/").
    PHA 2 (GPU) — với MỖI video vừa có trên Volume: chạy TransNetV2 (device=auto, tự dùng GPU) +
    similarity filtering NGUYÊN XI logic indexing/keyframe_extraction.py (mount thẳng file đó vào
    container, không copy/duplicate code) — ghi ảnh .jpg + frame_index.json vào CÙNG Volume
    "aic2026-newdataset" (thư mục con "keyframes/") -> modal_semantic_encode_newdataset.py /
    modal_ocr_encode_newdataset.py đọc tiếp được luôn với cờ --from-volume.

CHUẨN BỊ (1 lần/tài khoản Modal):
    pip install modal
    modal setup
    modal volume create aic2026-newdataset

CÁCH DÙNG (chạy trong thư mục gốc repo aic2026-project — MỖI thành viên tự chạy đúng tên của mình):
    modal run modal_keyframe_extract_gpu.py --member nhatanh
    modal run modal_keyframe_extract_gpu.py --member duong
    modal run modal_keyframe_extract_gpu.py --member kien
    modal run modal_keyframe_extract_gpu.py --member tien

    # Chỉ định thủ công vài file zip thay vì cả phần được giao (vd chạy lại 1 file lỗi):
    modal run modal_keyframe_extract_gpu.py --files "Video_N021-N030.zip"

Idempotent: mỗi file zip có marker riêng trên Volume (đã tải+giải nén xong thì bỏ qua khi chạy
lại); mỗi video đã có frame_index.json trên Volume rồi thì PHA 2 tự bỏ qua, không trích lại — chạy
lại đúng lệnh cũ nếu bị ngắt giữa chừng là tiếp tục đúng chỗ dang dở.

SAU KHI XONG (mọi thành viên): xem HUONG_DAN_DATASET_MOI_4_THANH_VIEN.md để chạy tiếp bước
semantic (modal_semantic_encode_newdataset.py), OCR (modal_ocr_encode_newdataset.py), ASR
(modal_asr_encode.py) và tải toàn bộ kết quả về máy.

GPU: mặc định "L4" (rẻ, đủ dùng cho TransNetV2 — model nhẹ). Đổi GPU_TYPE bên dưới nếu muốn nhanh
hơn (vd "A10G"/"L40S") — xem modal.com/pricing.
"""
import subprocess
import sys
from pathlib import Path

import modal

APP_NAME = "aic2026-keyframe-extract-gpu"
GPU_TYPE = "L4"
BASE_URL = "https://aic-data.ledo.io.vn"

MEMBER_FILES = {
    "nhatanh": ["Video_S01.zip", "Video_N001-N010.zip"],
    "duong": ["Video_N011-N020.zip", "Video_N021-N030.zip", "Video_N031-N040.zip"],
    "kien": ["Video_N041-N050.zip", "Video_N051-N060.zip", "Video_N061-N070.zip"],
    "tien": ["Video_N071-N080.zip", "Video_N081-N090.zip", "Video_N091-N100.zip"],
}
ALL_FILES = [f for files in MEMBER_FILES.values() for f in files]

NEWDATA_VOLUME_NAME = "aic2026-newdataset"  # Volume RIÊNG cho dataset mới, xem docstring đầu file
NEWDATA_MOUNT = "/data_new"
RAW_SUBDIR = "raw"
KEYFRAMES_SUBDIR = "keyframes"
MARKERS_SUBDIR = "_done_markers"

LOCAL_ROOT = Path(__file__).resolve().parent

app = modal.App(APP_NAME)
newdata_volume = modal.Volume.from_name(NEWDATA_VOLUME_NAME, create_if_missing=True)

cpu_image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("aria2", "unzip")
)

gpu_image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("ffmpeg", "libgl1", "libglib2.0-0")
    .pip_install(
        "torch",
        "opencv-python-headless",
        "numpy",
        "pyyaml",
        "tqdm",
        "transnetv2-pytorch",
        "ffmpeg-python",
    )
    .add_local_dir(str(LOCAL_ROOT / "indexing"), remote_path="/root/indexing")
)


def _read_keyframe_cfg() -> dict:
    import yaml

    with open(LOCAL_ROOT / "configs" / "pipeline_config.yaml", "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    return cfg.get("keyframe", {})


# --------------------------------------------------------------------------- PHA 1 (CPU): ingest zip

@app.function(image=cpu_image, volumes={NEWDATA_MOUNT: newdata_volume}, timeout=60)
def already_done(fname: str) -> bool:
    newdata_volume.reload()
    return (Path(NEWDATA_MOUNT) / MARKERS_SUBDIR / f"{fname}.done").exists()


@app.function(
    image=cpu_image,
    volumes={NEWDATA_MOUNT: newdata_volume},
    timeout=60 * 60,
)
def ingest_zip(fname: str) -> list:
    """Tải 1 file zip qua aria2c (đa luồng) -> giải nén -> gom video .mp4 vào Volume
    (thư mục raw/) -> ghi marker .done -> trả về list video_id (tên file không đuôi) vừa thêm."""
    url = f"{BASE_URL}/{fname}"
    tmp_dir = Path("/tmp") / Path(fname).stem
    tmp_dir.mkdir(parents=True, exist_ok=True)
    zip_path = tmp_dir / fname

    print(f"[Modal] Đang tải {url} bằng aria2c...")
    result = subprocess.run(
        ["aria2c", "-x", "16", "-s", "16", "-o", str(zip_path), url],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"aria2c tải {fname} thất bại: {result.stderr[-2000:]}")

    print(f"[Modal] Đang giải nén {fname}...")
    extract_dir = tmp_dir / "extracted"
    extract_dir.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["unzip", "-o", str(zip_path), "-d", str(extract_dir)],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"unzip {fname} thất bại: {result.stderr[-2000:]}")

    raw_dest = Path(NEWDATA_MOUNT) / RAW_SUBDIR
    raw_dest.mkdir(parents=True, exist_ok=True)
    video_ids = []
    for video_path in sorted(extract_dir.rglob("*.mp4")):
        video_id = video_path.stem
        dest_path = raw_dest / video_path.name
        dest_path.write_bytes(video_path.read_bytes())
        video_ids.append(video_id)

    marker_dir = Path(NEWDATA_MOUNT) / MARKERS_SUBDIR
    marker_dir.mkdir(parents=True, exist_ok=True)
    (marker_dir / f"{fname}.done").write_text("\n".join(video_ids), encoding="utf-8")
    newdata_volume.commit()

    print(f"[Modal] {fname}: đã gom {len(video_ids)} video vào Volume '{NEWDATA_VOLUME_NAME}'.")
    return video_ids


@app.function(image=cpu_image, volumes={NEWDATA_MOUNT: newdata_volume}, timeout=60)
def video_ids_from_marker(fname: str) -> list:
    newdata_volume.reload()
    marker_path = Path(NEWDATA_MOUNT) / MARKERS_SUBDIR / f"{fname}.done"
    if not marker_path.exists():
        return []
    return [line for line in marker_path.read_text(encoding="utf-8").splitlines() if line]


# --------------------------------------------------------------------------- PHA 2 (GPU): keyframe

@app.function(
    image=gpu_image,
    gpu=GPU_TYPE,
    volumes={NEWDATA_MOUNT: newdata_volume},
    timeout=60 * 60,
)
def extract_keyframes_for_video(video_id: str, kcfg: dict) -> dict:
    sys.path.insert(0, "/root/indexing")
    from keyframe_extraction import extract_keyframes_shot_similarity

    newdata_volume.reload()

    raw_dir = Path(NEWDATA_MOUNT) / RAW_SUBDIR
    video_path = None
    for candidate in raw_dir.glob(f"{video_id}.*"):
        video_path = candidate
        break
    if video_path is None:
        raise FileNotFoundError(f"Không thấy video gốc '{video_id}' trong {raw_dir}.")

    out_dir = Path(NEWDATA_MOUNT) / KEYFRAMES_SUBDIR
    out_dir.mkdir(parents=True, exist_ok=True)

    existing = out_dir / video_id / "frame_index.json"
    if existing.exists():
        print(f"[Modal] [{video_id}] Đã có frame_index.json trên Volume -> bỏ qua.")
        return {"video_id": video_id, "skipped": True}

    print(f"[Modal] [{video_id}] Đang trích keyframe (TransNetV2 + similarity)...")
    _, frame_index = extract_keyframes_shot_similarity(
        str(video_path),
        str(out_dir),
        candidate_every_seconds=kcfg.get("candidate_every_seconds", 0.5),
        similarity_threshold=kcfg.get("similarity_threshold", 0.075),
        transnet_threshold=kcfg.get("transnet_threshold", 0.5),
        max_frames=kcfg.get("max_frames_per_video"),
    )
    newdata_volume.commit()

    print(f"[Modal] [{video_id}] {len(frame_index)} keyframe -> đã ghi vào Volume.")
    return {"video_id": video_id, "n_frames": len(frame_index), "skipped": False}


@app.local_entrypoint()
def main(member: str = "", files: str = ""):
    if files:
        target_files = [f.strip() for f in files.split(",") if f.strip()]
    elif member:
        key = member.strip().lower()
        if key not in MEMBER_FILES:
            print(f"--member phải là 1 trong: {', '.join(MEMBER_FILES)}")
            sys.exit(1)
        target_files = MEMBER_FILES[key]
    else:
        print(
            "Cần chỉ 1 trong 2: --member <nhatanh|duong|kien|tien> hoặc --files \"a.zip,b.zip\". "
            "Xem docstring đầu file."
        )
        sys.exit(1)

    print(f"=== PHA 1/2: tải + giải nén {len(target_files)} file zip (không tốn GPU) ===")
    video_ids = []
    for fname in target_files:
        if already_done.remote(fname):
            ids = video_ids_from_marker.remote(fname)
            print(f"[{fname}] Đã tải xong từ trước -> tái dùng {len(ids)} video.")
        else:
            ids = ingest_zip.remote(fname)
        video_ids.extend(ids)
    video_ids = sorted(set(video_ids))
    print(f"Pha 1 xong: {len(video_ids)} video sẵn sàng trên Volume '{NEWDATA_VOLUME_NAME}'.")

    if not video_ids:
        print("Không có video nào để trích keyframe.")
        return

    print(f"\n=== PHA 2/2: trích keyframe {len(video_ids)} video trên GPU Modal ({GPU_TYPE}) ===")
    kcfg = _read_keyframe_cfg()
    n_ok, n_skip, n_fail = 0, 0, 0
    for vid in video_ids:
        print(f"[{vid}] Đang xử lý...")
        try:
            result = extract_keyframes_for_video.remote(vid, kcfg)
        except Exception as e:
            print(f"[{vid}] !!! LỖI khi trích keyframe: {e}")
            n_fail += 1
            continue
        if result.get("skipped"):
            n_skip += 1
        else:
            print(f"[{vid}] Xong: {result['n_frames']} keyframe.")
            n_ok += 1

    print(f"\nHoàn tất: {n_ok} video mới trích, {n_skip} bỏ qua (đã có sẵn), {n_fail} lỗi.")
    print(
        "Tiếp theo: modal run modal_semantic_encode_newdataset.py --from-volume, "
        "modal run modal_ocr_encode_newdataset.py --from-volume, "
        "modal run modal_asr_encode.py --member <tên> — xem HUONG_DAN_DATASET_MOI_4_THANH_VIEN.md."
    )
