"""
Chạy ASR (wav2vec2-base-vietnamese-250h qua HF transformers pipeline, xem
indexing/audio_asr/run_asr.py) trên GPU thuê theo giây qua Modal, cho dataset video MỚI — DÙNG
CHUNG Volume RIÊNG "aic2026-newdataset" với modal_keyframe_extract_gpu.py (thư mục con "raw/" —
video gốc đã tải sẵn ở Bước 1, không tải lại). KHÔNG import modal_keyframe_extract_gpu.py (tránh
Modal vô tình đăng ký/chạy luôn app của file đó như tác dụng phụ của import Python thường) — các
hằng số MEMBER_FILES/BASE_URL/Volume bên dưới CỐ Ý lặp lại giống hệt file đó.

Output tải về data_newdataset/processed/transcripts/ (KHÔNG phải data/processed/transcripts/ của
dataset L21-L30 cũ) — xem HUONG_DAN_DATASET_MOI_4_THANH_VIEN.md.

CHUẨN BỊ: đã chạy modal_keyframe_extract_gpu.py trước (Volume "aic2026-newdataset" đã có video gốc
trong thư mục raw/, ứng với phần --member được giao).

CÁCH DÙNG (chạy trong thư mục gốc repo aic2026-project — MỖI thành viên tự chạy đúng tên của mình):
    modal run modal_asr_encode.py --member nhatanh
    modal run modal_asr_encode.py --member duong
    modal run modal_asr_encode.py --member kien
    modal run modal_asr_encode.py --member tien

    # Chỉ 1 video cụ thể:
    modal run modal_asr_encode.py --member nhatanh --video-id N005

GPU: mặc định "A10G" (đủ VRAM cho wav2vec2, giá/hiệu năng tốt). Đổi GPU_TYPE bên dưới nếu muốn
khác — xem modal.com/pricing.
"""
import json
import sys
from pathlib import Path

import modal

APP_NAME = "aic2026-asr-wav2vec2"
GPU_TYPE = "A10G"
BASE_URL = "https://aic-data.ledo.io.vn"

# Lặp lại y hệt modal_keyframe_extract_gpu.py — xem lý do trong docstring đầu file.
MEMBER_FILES = {
    "nhatanh": ["Video_S01.zip", "Video_N001-N010.zip"],
    "duong": ["Video_N011-N020.zip", "Video_N021-N030.zip", "Video_N031-N040.zip"],
    "kien": ["Video_N041-N050.zip", "Video_N051-N060.zip", "Video_N061-N070.zip"],
    "tien": ["Video_N071-N080.zip", "Video_N081-N090.zip", "Video_N091-N100.zip"],
}

NEWDATA_VOLUME_NAME = "aic2026-newdataset"  # RIÊNG, dùng chung với modal_keyframe_extract_gpu.py
NEWDATA_MOUNT = "/data_new"
RAW_SUBDIR = "raw"
MARKERS_SUBDIR = "_done_markers"

LOCAL_ROOT = Path(__file__).resolve().parent
LOCAL_TRANSCRIPTS_DIR = LOCAL_ROOT / "data_newdataset" / "processed" / "transcripts"
LOCAL_ASR_MODULE_DIR = LOCAL_ROOT / "indexing" / "audio_asr"  # mount thẳng vào container — TÁI SỬ
# DỤNG nguyên xi logic extract_audio.py/run_asr.py.

app = modal.App(APP_NAME)
newdata_volume = modal.Volume.from_name(NEWDATA_VOLUME_NAME, create_if_missing=True)

image = (
    modal.Image.debian_slim(python_version="3.11")
    .apt_install("ffmpeg")
    .pip_install(
        "torch",
        "torchaudio",
        "transformers>=4.41,<5.0",
        "pyyaml",
    )
    .add_local_dir(str(LOCAL_ASR_MODULE_DIR), remote_path="/root/audio_asr")
)


def _read_asr_cfg() -> dict:
    import yaml

    with open(LOCAL_ROOT / "configs" / "pipeline_config.yaml", "r", encoding="utf-8") as f:
        cfg = yaml.safe_load(f)
    return cfg


# --------------------------------------------------------------------------- ingest (Pha 1, CPU) —
# lặp lại y hệt modal_keyframe_extract_gpu.py: thường KHÔNG cần gọi tới (video gốc đã có sẵn trên
# Volume từ Bước 1), chỉ dùng khi chạy modal_asr_encode.py cho member CHƯA từng trích keyframe.

@app.function(
    image=modal.Image.debian_slim(python_version="3.11").apt_install("aria2", "unzip"),
    volumes={NEWDATA_MOUNT: newdata_volume},
    timeout=60,
)
def already_done(fname: str) -> bool:
    newdata_volume.reload()
    return (Path(NEWDATA_MOUNT) / MARKERS_SUBDIR / f"{fname}.done").exists()


@app.function(
    image=modal.Image.debian_slim(python_version="3.11").apt_install("aria2", "unzip"),
    volumes={NEWDATA_MOUNT: newdata_volume},
    timeout=60 * 60,
)
def ingest_zip(fname: str) -> list:
    import subprocess

    url = f"{BASE_URL}/{fname}"
    tmp_dir = Path("/tmp") / Path(fname).stem
    tmp_dir.mkdir(parents=True, exist_ok=True)
    zip_path = tmp_dir / fname

    result = subprocess.run(
        ["aria2c", "-x", "16", "-s", "16", "-o", str(zip_path), url],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"aria2c tải {fname} thất bại: {result.stderr[-2000:]}")

    extract_dir = tmp_dir / "extracted"
    extract_dir.mkdir(parents=True, exist_ok=True)
    result = subprocess.run(
        ["unzip", "-o", str(zip_path), "-d", str(extract_dir)],
        capture_output=True, text=True,
    )
    if result.returncode != 0:
        raise RuntimeError(f"unzip {fname} thất bại: {result.stderr[-2000:]}")

    raw_dest = Path(NEWDATA_MOUNT) / RAW_SUBDIR
    raw_dest.mkdir(parents=True, exist_ok=True)
    video_ids = []
    for video_path in sorted(extract_dir.rglob("*.mp4")):
        dest_path = raw_dest / video_path.name
        dest_path.write_bytes(video_path.read_bytes())
        video_ids.append(video_path.stem)

    marker_dir = Path(NEWDATA_MOUNT) / MARKERS_SUBDIR
    marker_dir.mkdir(parents=True, exist_ok=True)
    (marker_dir / f"{fname}.done").write_text("\n".join(video_ids), encoding="utf-8")
    newdata_volume.commit()
    return video_ids


@app.function(image=modal.Image.debian_slim(python_version="3.11"), volumes={NEWDATA_MOUNT: newdata_volume}, timeout=60)
def video_ids_from_marker(fname: str) -> list:
    newdata_volume.reload()
    marker_path = Path(NEWDATA_MOUNT) / MARKERS_SUBDIR / f"{fname}.done"
    if not marker_path.exists():
        return []
    return [line for line in marker_path.read_text(encoding="utf-8").splitlines() if line]


# --------------------------------------------------------------------------- ASR (Pha 2, GPU)

@app.cls(
    image=image,
    gpu=GPU_TYPE,
    volumes={NEWDATA_MOUNT: newdata_volume},
    timeout=60 * 60,
    scaledown_window=120,
)
class ASRRunner:
    @modal.enter()
    def setup(self):
        sys.path.insert(0, "/root/audio_asr")
        import run_asr as _run_asr

        self._run_asr = _run_asr
        self._pipeline_cache = None

        # Cache pipeline ASR qua toàn bộ lô video (chỉ nạp model 1 lần) bằng cách monkey-patch
        # load_asr_pipeline() để trả lại đúng pipeline đã nạp từ lần gọi thứ 2 trở đi.
        self._orig_load_asr_pipeline = _run_asr.load_asr_pipeline

        def _cached_load_asr_pipeline(cfg):
            if self._pipeline_cache is None:
                self._pipeline_cache = self._orig_load_asr_pipeline(cfg)
            return self._pipeline_cache

        _run_asr.load_asr_pipeline = _cached_load_asr_pipeline

    @modal.method()
    def transcribe(self, video_id: str, cfg: dict) -> list:
        from extract_audio import extract_audio

        newdata_volume.reload()

        raw_dir = Path(NEWDATA_MOUNT) / RAW_SUBDIR
        video_path = None
        for candidate in raw_dir.glob(f"{video_id}.*"):
            video_path = candidate
            break
        if video_path is None:
            raise FileNotFoundError(f"Không thấy video gốc '{video_id}' trong {raw_dir}.")

        wav_path = extract_audio(str(video_path), out_dir="/tmp/_audio")
        segments = self._run_asr.transcribe_video(video_id, wav_path, cfg)
        print(f"[Modal] [{video_id}] {len(segments)} đoạn transcript.")
        return segments


def _download_result(video_id: str, segments: list) -> None:
    LOCAL_TRANSCRIPTS_DIR.mkdir(parents=True, exist_ok=True)
    with open(LOCAL_TRANSCRIPTS_DIR / f"{video_id}.json", "w", encoding="utf-8") as f:
        json.dump(segments, f, ensure_ascii=False, indent=2)


@app.local_entrypoint()
def main(member: str = "", video_id: str = "", files: str = ""):
    if files:
        target_files = [f.strip() for f in files.split(",") if f.strip()]
    elif member:
        key = member.strip().lower()
        if key not in MEMBER_FILES:
            print(f"--member phải là 1 trong: {', '.join(MEMBER_FILES)}")
            sys.exit(1)
        target_files = MEMBER_FILES[key]
    else:
        print(
            "Cần chỉ 1 trong 2: --member <nhatanh|duong|kien|tien> hoặc --files \"a.zip,b.zip\". "
            "Xem docstring đầu file."
        )
        sys.exit(1)

    print(f"Đang kiểm tra video gốc trên Volume cho {len(target_files)} file zip...")
    video_ids = []
    for fname in target_files:
        if already_done.remote(fname):
            ids = video_ids_from_marker.remote(fname)
        else:
            print(f"[{fname}] Chưa có trên Volume -> tự tải (thường đã có sẵn nếu đã chạy "
                  f"modal_keyframe_extract_gpu.py trước).")
            ids = ingest_zip.remote(fname)
        video_ids.extend(ids)
    video_ids = sorted(set(video_ids))

    if video_id:
        if video_id not in video_ids:
            print(f"'{video_id}' không thuộc phần được giao cho --member này.")
            sys.exit(1)
        video_ids = [video_id]

    pending, n_skipped = [], 0
    for vid in video_ids:
        if (LOCAL_TRANSCRIPTS_DIR / f"{vid}.json").exists():
            n_skipped += 1
        else:
            pending.append(vid)
    print(f"{len(pending)}/{len(video_ids)} video cần ASR ({n_skipped} đã có kết quả sẵn — bỏ qua).")
    if not pending:
        print("Không còn gì để làm.")
        return

    print(f"\n=== ASR {len(pending)} video trên GPU Modal ({GPU_TYPE}) ===")
    cfg = _read_asr_cfg()
    runner = ASRRunner()
    n_ok, n_fail = 0, 0
    for vid in pending:
        print(f"[{vid}] Đang chạy ASR...")
        try:
            segments = runner.transcribe.remote(vid, cfg)
        except Exception as e:
            print(f"[{vid}] !!! LỖI khi ASR: {e}")
            n_fail += 1
            continue
        _download_result(vid, segments)
        print(f"[{vid}] Xong: {len(segments)} đoạn transcript -> đã lưu vào {LOCAL_TRANSCRIPTS_DIR}/")
        n_ok += 1

    print(f"\nHoàn tất: {n_ok} video mới ASR, {n_skipped} bỏ qua (đã có sẵn), {n_fail} lỗi.")
