"""
BẢN RIÊNG của modal_semantic_encode.py, CHỈ dùng cho dataset video MỚI (xem
modal_keyframe_extract_gpu.py + HUONG_DAN_DATASET_MOI_4_THANH_VIEN.md) — đọc keyframe từ Volume
RIÊNG "aic2026-newdataset" (KHÔNG phải "aic2026-keyframes" của dataset L21-L30 cũ) và tải vector về
thư mục local RIÊNG data_newdataset/processed/features/ (KHÔNG phải data/processed/features/ cũ).
Tách hẳn file này ra thay vì thêm cờ vào modal_semantic_encode.py để dataset cũ và dataset mới
KHÔNG BAO GIỜ lẫn/đè vector lên nhau, dù chạy nhầm lệnh.

Muốn dùng dataset MỚI cho search thật (build FAISS/BM25 + serve UI), CHỦ ĐỘNG gộp thủ công
data_newdataset/ vào data/ sau khi đã kiểm tra kỹ — xem HUONG_DAN_DATASET_MOI_4_THANH_VIEN.md.

Cùng model/logic/schema với indexing/semantic_feature/extract_semantic.py — chỉ khác NƠI CHẠY
(GPU Modal) và NƠI ĐỌC/GHI (Volume + thư mục local riêng cho dataset mới).

CHUẨN BỊ: đã chạy modal_keyframe_extract_gpu.py trước (Volume "aic2026-newdataset" đã có keyframe).

CÁCH DÙNG (chạy trong thư mục gốc repo aic2026-project):
    modal run modal_semantic_encode_newdataset.py --from-volume

    # Chỉ 1 video cụ thể:
    modal run modal_semantic_encode_newdataset.py --from-volume --video-id N005

CHI PHÍ: GPU "L40S" mặc định (đủ VRAM cho jina-clip-v2 ~0.9B tham số, batch lớn). Đổi GPU_TYPE bên
dưới nếu muốn rẻ hơn/nhanh hơn — xem modal.com/pricing.
"""
import json
import sys
from pathlib import Path

import modal

APP_NAME = "aic2026-semantic-jina-newdataset"
GPU_TYPE = "L40S"
MODEL_NAME = "jinaai/jina-clip-v2"  # PHẢI khớp configs/pipeline_config.yaml -> semantic_feature.model

VOLUME_NAME = "aic2026-newdataset"  # RIÊNG, xem docstring đầu file
VOLUME_MOUNT = "/data_new"
KEYFRAMES_SUBDIR = "keyframes"
FEATURES_SUBDIR = "processed/features"

LOCAL_ROOT = Path(__file__).resolve().parent
LOCAL_FEATURES_DIR = LOCAL_ROOT / "data_newdataset" / "processed" / "features"

app = modal.App(APP_NAME)
volume = modal.Volume.from_name(VOLUME_NAME, create_if_missing=True)

image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "torch",
        "torchvision",
        "transformers>=4.41,<5.0",  # xem lý do pin trong modal_semantic_encode.py (bản gốc)
        "einops",
        "timm",
        "pillow",
        "numpy",
    )
)


@app.function(image=image, volumes={VOLUME_MOUNT: volume}, timeout=5 * 60)
def list_volume_video_ids() -> list:
    """Liệt kê MỌI video_id đã có sẵn keyframe (frame_index.json) trên Volume
    'aic2026-newdataset' — ghi bởi modal_keyframe_extract_gpu.py."""
    volume.reload()
    base = Path(VOLUME_MOUNT) / KEYFRAMES_SUBDIR
    if not base.exists():
        return []
    video_ids = sorted(
        p.name for p in base.iterdir() if p.is_dir() and (p / "frame_index.json").exists()
    )
    print(f"[Modal] Tìm thấy {len(video_ids)} video có sẵn keyframe trên Volume '{VOLUME_NAME}'.")
    return video_ids


@app.cls(
    image=image,
    gpu=GPU_TYPE,
    volumes={VOLUME_MOUNT: volume},
    timeout=60 * 60,
    scaledown_window=120,
)
class JinaEncoder:
    @modal.enter()
    def load_model(self):
        from transformers import AutoModel

        print(f"[Modal] Đang tải model {MODEL_NAME} lên GPU ({GPU_TYPE})...")
        self.model = AutoModel.from_pretrained(MODEL_NAME, trust_remote_code=True).to("cuda")
        print("[Modal] Model đã sẵn sàng.")

    @modal.method()
    def encode_video(self, video_id: str) -> dict:
        import numpy as np
        from PIL import Image as PILImage

        volume.reload()

        video_dir = Path(VOLUME_MOUNT) / KEYFRAMES_SUBDIR / video_id
        frame_index_path = video_dir / "frame_index.json"
        if not frame_index_path.exists():
            raise FileNotFoundError(f"Không thấy {frame_index_path} trên Volume.")

        with open(frame_index_path, "r", encoding="utf-8") as f:
            frame_index = json.load(f)

        images = []
        for frame in frame_index:
            img_path = video_dir / f"frame_{frame['frame_id']:06d}.jpg"
            images.append(PILImage.open(img_path).convert("RGB"))

        if images:
            vectors = self.model.encode_image(
                images, batch_size=32, convert_to_numpy=True,
                normalize_embeddings=True, show_progress_bar=False,
            ).astype(np.float32)
        else:
            vectors = np.zeros((0, 1024), dtype=np.float32)

        out_dir = Path(VOLUME_MOUNT) / FEATURES_SUBDIR
        out_dir.mkdir(parents=True, exist_ok=True)
        np.save(out_dir / f"{video_id}_semantic.npy", vectors)
        with open(out_dir / f"{video_id}_semantic_frame_index.json", "w", encoding="utf-8") as f:
            json.dump(frame_index, f, ensure_ascii=False, indent=2)

        volume.commit()

        n_frames = int(vectors.shape[0])
        dim = int(vectors.shape[1]) if n_frames else None
        print(f"[Modal] [{video_id}] {n_frames} vector (dim={dim}) -> đã ghi vào Volume.")
        return {"video_id": video_id, "n_frames": n_frames, "dim": dim}


def _download_result(video_id: str) -> bool:
    LOCAL_FEATURES_DIR.mkdir(parents=True, exist_ok=True)
    ok = True
    for fname in (f"{video_id}_semantic.npy", f"{video_id}_semantic_frame_index.json"):
        remote_path = f"/{FEATURES_SUBDIR}/{fname}"
        try:
            data = b"".join(chunk for chunk in volume.read_file(remote_path))
        except FileNotFoundError:
            print(f"  !!! Không thấy {remote_path} trên Volume — encode có thể đã lỗi.")
            ok = False
            continue
        (LOCAL_FEATURES_DIR / fname).write_bytes(data)
    return ok


@app.local_entrypoint()
def main(from_volume: bool = False, video_id: str = ""):
    if not from_volume:
        print(
            "Cần cờ --from-volume (file này CHỈ hỗ trợ đọc keyframe từ Volume "
            "'aic2026-newdataset' — đã trích bằng modal_keyframe_extract_gpu.py)."
        )
        sys.exit(1)

    print("Đang liệt kê video đã có sẵn keyframe trên Volume...")
    video_ids = list_volume_video_ids.remote()
    if not video_ids:
        print("Volume chưa có video nào — chạy modal_keyframe_extract_gpu.py trước.")
        sys.exit(1)
    if video_id:
        if video_id not in video_ids:
            print(f"Volume không có video '{video_id}'.")
            sys.exit(1)
        video_ids = [video_id]

    pending, n_skipped = [], 0
    for vid in video_ids:
        if (LOCAL_FEATURES_DIR / f"{vid}_semantic.npy").exists() \
                and (LOCAL_FEATURES_DIR / f"{vid}_semantic_frame_index.json").exists():
            n_skipped += 1
        else:
            pending.append(vid)
    print(f"{len(pending)}/{len(video_ids)} video cần encode ({n_skipped} đã có kết quả sẵn — bỏ qua).")
    if not pending:
        print("Không còn gì để làm.")
        return

    print(f"\n=== Encode {len(pending)} video trên GPU Modal ({GPU_TYPE}) ===")
    encoder = JinaEncoder()
    n_ok, n_fail = 0, 0
    for vid in pending:
        print(f"[{vid}] Đang encode...")
        try:
            result = encoder.encode_video.remote(vid)
        except Exception as e:
            print(f"[{vid}] !!! LỖI khi encode: {e}")
            n_fail += 1
            continue
        print(f"[{vid}] Xong: {result['n_frames']} vector, dim={result['dim']}")
        if _download_result(vid):
            print(f"[{vid}] Đã lưu vào {LOCAL_FEATURES_DIR}/")
            n_ok += 1
        else:
            n_fail += 1

    print(f"\nHoàn tất: {n_ok} video mới encode, {n_skipped} bỏ qua (đã có sẵn), {n_fail} lỗi.")
