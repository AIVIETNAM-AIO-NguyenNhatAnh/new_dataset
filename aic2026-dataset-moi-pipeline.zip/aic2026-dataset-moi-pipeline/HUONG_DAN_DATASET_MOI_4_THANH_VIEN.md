# Hướng dẫn: Xử lý dataset video MỚI trên GPU Modal — chia 4 thành viên

**Nếu bạn nhận bộ này qua file `aic2026-dataset-moi-pipeline.zip` (KHÔNG phải đã có sẵn nguyên repo
`aic2026-project`):** giải nén, `cd` vào đúng thư mục vừa giải nén rồi chạy lệnh — KHÔNG cần clone
gì thêm. Zip này tự chứa đủ 3 thứ bắt buộc để 4 script Modal chạy được độc lập:
- 4 file `modal_*.py` (keyframe/semantic/OCR/ASR) + file hướng dẫn này.
- `configs/pipeline_config.yaml` — cả 4 script đều đọc file này (tham số keyframe/semantic/ocr/asr).
- `indexing/` (`keyframe_extraction.py`, `ocr/run_ocr.py` + phụ trợ, `audio_asr/run_asr.py` +
  `extract_audio.py`) — Modal mount thẳng các file này vào container GPU (`add_local_dir`), tái sử
  dụng đúng logic gốc thay vì copy lại code, nên KHÔNG THỂ THIẾU.

Nếu bạn ĐÃ có sẵn repo `aic2026-project` đầy đủ (vd. đã clone git từ trước) thì chỉ cần copy 5 file
gốc (`modal_keyframe_extract_gpu.py`, `modal_semantic_encode_newdataset.py`,
`modal_ocr_encode_newdataset.py`, `modal_asr_encode.py`, file `.md` này) đè vào thư mục gốc repo —
`configs/` và `indexing/` lúc đó dùng lại bản đã có sẵn trong repo, không cần chép từ zip nữa.

**Dữ liệu dataset MỚI này lưu HOÀN TOÀN TÁCH BIỆT với dataset cũ (L21-L30)** — dùng riêng 1 Modal
Volume (`aic2026-newdataset`) và riêng 1 thư mục local (`data_newdataset/`), không đụng tới Volume
`aic2026-raw-videos`/`aic2026-keyframes` hay thư mục `data/` của dataset cũ. Vì vậy cả 4 bước dưới
đây dùng bộ file `..._newdataset` / `modal_keyframe_extract_gpu.py` riêng, KHÔNG dùng
`modal_semantic_encode.py`/`modal_ocr_encode.py` gốc (2 file gốc đó vẫn dùng cho dataset L21-L30 cũ
như bình thường).

Dataset mới (nguồn `https://aic-data.ledo.io.vn`): `Video_S01.zip` + 10 file `Video_N0xx-N0yy.zip`
(mỗi file ước tính 10 video). Toàn bộ chạy trên GPU **Modal** (không phải máy cá nhân), chia sẵn
cho 4 thành viên trong `MEMBER_FILES` (khai báo trong `modal_keyframe_extract_gpu.py` và
`modal_asr_encode.py` — 2 file phải khớp nhau):

| Thành viên | `--member` | File zip phụ trách |
|---|---|---|
| Nhất Anh | `nhatanh` | `Video_S01.zip`, `Video_N001-N010.zip` |
| Dương | `duong` | `Video_N011-N020.zip`, `Video_N021-N030.zip`, `Video_N031-N040.zip` |
| Kiên | `kien` | `Video_N041-N050.zip`, `Video_N051-N060.zip`, `Video_N061-N070.zip` |
| Tiến | `tien` | `Video_N071-N080.zip`, `Video_N081-N090.zip`, `Video_N091-N100.zip` |

Mỗi người chạy **4 lệnh** theo đúng thứ tự, trên **tài khoản Modal của chính mình** (khuyến nghị —
chạy song song 4 người trên CÙNG 1 tài khoản vẫn được nếu chia sẻ Volume, nhưng tốn tiền GPU của 1
người; xem ghi chú cuối file).

---

## Chuẩn bị (1 lần, mỗi thành viên tự làm trên máy mình)

```
cd đường-dẫn-tới/aic2026-project
pip install modal
modal setup
modal volume create aic2026-newdataset
```

Chỉ **1 Volume duy nhất** (`aic2026-newdataset`) cho toàn bộ dataset mới — video gốc, keyframe,
vector semantic, OCR đều ghi chung vào đây (tách biệt hoàn toàn với Volume của dataset cũ).

Nếu 4 người dùng CHUNG 1 tài khoản Modal (khuyến nghị để dữ liệu gom vào đúng 1 Volume, đỡ phải
gộp tay ở bước cuối) — chỉ 1 người cần chạy `modal volume create`, người còn lại `modal setup`
bằng CÙNG tài khoản (hoặc dùng chung API token, xem `modal.com/docs/guide/service-users`).

---

## Bước 1 — Trích keyframe bằng GPU (mỗi người chạy đúng tên của mình)

```
modal run modal_keyframe_extract_gpu.py --member <nhatanh|duong|kien|tien>
```

Tự động: tải zip được giao → giải nén → gom video vào Volume `aic2026-newdataset` (thư mục `raw/`)
→ chạy TransNetV2 (GPU) trích keyframe → ghi ảnh `.jpg` + `frame_index.json` vào cùng Volume (thư
mục `keyframes/`). Idempotent — bị ngắt giữa chừng thì chạy lại đúng lệnh, tự bỏ qua phần đã xong.

## Bước 2 — Encode semantic (jina-clip-v2) cho các video vừa trích

```
modal run modal_semantic_encode_newdataset.py --from-volume
```

**Lưu ý: dùng file `modal_semantic_encode_newdataset.py` (có hậu tố `_newdataset`), KHÔNG dùng
`modal_semantic_encode.py` gốc** — file gốc đọc/ghi Volume `aic2026-keyframes` của dataset L21-L30
cũ, dùng nhầm sẽ lẫn dữ liệu 2 dataset. Cờ `--from-volume` tự tìm MỌI video đã có keyframe trên
Volume `aic2026-newdataset` (không chỉ phần của riêng thành viên này — nếu dùng chung tài khoản,
ai chạy trước cũng được, không trùng công vì mỗi video chỉ encode 1 lần, video đã xong sẽ tự bỏ
qua). Tải kết quả `.npy` về `data_newdataset/processed/features/`.

## Bước 3 — OCR (PaddleOCR + VietOCR) cho các video vừa trích

```
modal run modal_ocr_encode_newdataset.py --from-volume
```

**Cũng dùng bản `_newdataset`, không dùng `modal_ocr_encode.py` gốc** — lý do giống Bước 2. Tải
kết quả `.json` về `data_newdataset/processed/ocr_text/`.

## Bước 4 — ASR (wav2vec2) cho video được giao

```
modal run modal_asr_encode.py --member <nhatanh|duong|kien|tien>
```

File này (không có bản `_newdataset` riêng — đã build sẵn để trỏ thẳng vào Volume
`aic2026-newdataset`) đọc trực tiếp audio từ video gốc trên Volume `aic2026-newdataset` (thư mục
`raw/`, đã có sẵn từ Bước 1, không tải lại). Tải kết quả `.json` về
`data_newdataset/processed/transcripts/`.

---

## Bước 5 — Tải TOÀN BỘ kết quả về máy (ảnh keyframe + mọi thứ còn lại)

Bước 2-4 đã tự tải `.npy`/`.json` (vector, OCR, ASR) về `data_newdataset/processed/...` rồi — CHỈ
CÒN thiếu ẢNH KEYFRAME THẬT (`.jpg`), vẫn đang nằm trên Volume. Tải về bằng lệnh Modal CLI (không
cần code riêng):

```
modal volume get aic2026-newdataset keyframes data_newdataset/keyframes
```

Kiểm tra đã đủ:
```
ls data_newdataset/keyframes | wc -l          # số thư mục video (phải khớp tổng số video đã xử lý)
ls data_newdataset/processed/features | wc -l
ls data_newdataset/processed/ocr_text | wc -l
ls data_newdataset/processed/transcripts | wc -l
```

---

## Sau khi 4 người xong hết

Nếu mỗi người tự chạy trên tài khoản Modal RIÊNG (Volume `aic2026-newdataset` riêng, không gộp
sẵn): mỗi người có 1 bộ `data_newdataset/keyframes/`,
`data_newdataset/processed/{features,ocr_text,transcripts}/` CHỈ chứa phần video của mình — cần 1
người tổng hợp: copy nội dung 4 bộ thư mục đó gộp vào chung 1 máy (không trùng tên file vì
video_id khác nhau).

Nếu 4 người dùng CHUNG 1 tài khoản Modal — chỉ 1 người cần làm bước tổng hợp (chạy Bước 5 lấy về
là đã có đủ TOÀN BỘ dữ liệu của cả 4 người, vì tất cả ghi chung 1 Volume).

**`data_newdataset/` vẫn đang TÁCH RIÊNG khỏi `data/` (dataset cũ) — chưa dùng được cho search
thật.** Muốn đưa dataset mới vào chung hệ thống tìm kiếm (FAISS/BM25/UI), phải CHỦ ĐỘNG gộp thủ
công sau khi đã kiểm tra kỹ dữ liệu (vd. copy `data_newdataset/keyframes/*` vào `data/keyframes/`,
tương tự cho `processed/features`, `processed/ocr_text`, `processed/transcripts` — không trùng tên
vì `video_id` dataset mới (`N001`...`N100`, `S01`) khác hẳn dataset cũ (`L21_V001`...)), rồi mới
chạy:

```
python3 indexes/faiss/build_index.py
python3 indexes/meilisearch/build_index_bm25_baseline.py
modal run modal_backend_deploy.py::upload_index
modal deploy modal_backend_deploy.py
```

Bước gộp này KHÔNG tự động — chỉ làm khi bạn thực sự muốn dataset mới xuất hiện trong kết quả tìm
kiếm chung.

## Sự cố thường gặp

**Lỗi 403/timeout lúc tải zip (aria2c)** — server nguồn `aic-data.ledo.io.vn` tạm quá tải, chạy lại
đúng lệnh cũ (idempotent, tự bỏ qua phần đã xong).

**GPU "L4"/"A10G" báo không cấp phát được** — đổi `GPU_TYPE` trong `modal_keyframe_extract_gpu.py`
(mặc định `"L4"`) hoặc `modal_asr_encode.py` (mặc định `"A10G"`) sang loại khác đang rảnh hơn (vd
`"T4"`), theo đúng phần "Sự cố thường gặp" trong `HUONG_DAN_DOI_TAI_KHOAN_MODAL.md`.

**`modal volume get` báo Volume/path không tồn tại** — kiểm tra đã chạy xong Bước 1 (Volume
`aic2026-newdataset` phải có ít nhất 1 video trong thư mục `keyframes/`) trước khi tải về.
