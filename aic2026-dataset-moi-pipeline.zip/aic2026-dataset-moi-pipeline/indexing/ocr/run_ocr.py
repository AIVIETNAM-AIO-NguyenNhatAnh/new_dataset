"""
OCR trên keyframe — theo khuyến nghị trong OCR.docx: PP-OCRv6_medium (PaddleOCR) làm
engine chính, EasyOCR làm fallback nếu PaddleOCR chưa cài/tải được model (giữ pipeline
chạy được ngay cả khi thiếu mạng/thiếu package, cùng triết lý primary/fallback với
indexing/audio_asr/run_asr.py).

RECOGNIZER PHỤ — VietOCR (tuỳ chọn, mặc định BẬT, xem cfg ocr.vietocr): OCR.docx không đề
cập VietOCR (báo cáo chỉ khuyến nghị PP-OCRv6 end-to-end) — đây là hướng bổ sung riêng để xử
lý đúng rủi ro "dấu tiếng Việt sai" nêu ở mục 9 báo cáo. KHÔNG thay thế engine chính: chỉ chạy
lại VietOCR (train chuyên tiếng Việt) trên phần crop của box có confidence thấp từ PP-OCRv6/
EasyOCR (dưới ngưỡng vietocr.trigger_confidence nhưng vẫn qua được min_confidence), rồi giữ
kết quả nào có score cao hơn — giữ nguyên tốc độ batch của engine chính cho phần lớn box "dễ",
chỉ tốn thêm 1 lần suy luận cho box "khó". Xem load_vietocr_recognizer() bên dưới.

KHÔNG implement trong baseline này (xem indexing/ocr/README.md để biết lý do và cách
cắm thêm sau): DeepSolo+PARSeq fine-tune riêng, HunyuanOCR-1.5, Gemini OCR làm xác minh
lần 2 thật (indexing/ocr/verify_hard_frames.py có sẵn interface, mặc định NullVerifier
không gọi API nào), agent LLM chọn khi nào cần OCR (search/text_matching/ocr_intent.py
dùng heuristic thay vì agent thật).

Output: data/processed/ocr_text/{video_id}.json -> list các record, mỗi record:
    {
      "video_id", "frame_id", "timestamp",           # tương thích ngược, = temporal start
      "raw_text", "normalized_text", "no_accent_text", "char_ngrams",
      "geometry": {"bbox": [x,y,w,h], "score": ..},
      "temporal": {"frame_id_start", "frame_id_end", "timestamp_start", "timestamp_end",
                    "frame_ids": [...], "n_merged": ..},
      "likely_static_overlay": bool,                  # nghi ngờ ticker/logo cố định
      "needs_verification": bool, "verification": null | {...},
      "provenance": {"model", "engine", "recognizer", "config", "run_at"},
      # "recognizer": tên model THỰC SỰ tạo ra "text" cuối cùng — bằng "engine" nếu dùng
      # nguyên kết quả engine chính, hoặc "vietocr" nếu VietOCR đọc lại box này với score cao
      # hơn (xem RECOGNIZER PHỤ ở đầu file).
    }
Xem quy ước format đầy đủ tại docs/pipeline.md và đặc tả gốc trong OCR.docx mục 6.

Dùng: python indexing/ocr/run_ocr.py --video_id xxx   (phải chạy keyframe_extraction.py trước)
"""
import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import yaml
from tqdm import tqdm

from text_normalize import enrich_text_fields
from temporal_merge import merge_temporal, flag_static_overlays
from verify_hard_frames import NullVerifier, apply_verification


def load_config(config_path="configs/pipeline_config.yaml"):
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


# --------------------------------------------------------------------------- engine loading

def load_ocr_engine(cfg_ocr: dict):
    """Trả (engine_name, run_fn) với run_fn(image_path) -> [(bbox_xyxy_points, text, score), ...].

    Thử PaddleOCR (PP-OCRv6) trước; nếu import/khởi tạo lỗi (chưa cài, model chưa tải
    được do offline...) thì fallback sang EasyOCR, giống hệt cách run_asr.py fallback
    giữa 2 model ASR.
    """
    primary = cfg_ocr.get("engine", "paddleocr")
    fallback = cfg_ocr.get("fallback_engine", "easyocr")
    lang = cfg_ocr.get("lang", "vi")

    if primary == "paddleocr":
        try:
            return "paddleocr", _make_paddleocr_runner(cfg_ocr, lang)
        except Exception as e:
            print(f"[OCR] Không khởi tạo được PaddleOCR ({e}). Chuyển sang fallback: {fallback}")

    if fallback == "easyocr" or primary == "easyocr":
        return "easyocr", _make_easyocr_runner(cfg_ocr.get("languages", ["vi", "en"]))

    raise RuntimeError(f"Không có engine OCR nào khởi tạo được (primary={primary}, fallback={fallback}).")


def _make_paddleocr_runner(cfg_ocr: dict, lang: str):
    from paddleocr import PaddleOCR

    ocr_version = cfg_ocr.get("paddleocr_version")  # vd. "PP-OCRv6" — tên tham số có thể
    # đổi giữa các bản paddleocr; kiểm tra `PaddleOCR.__init__` của bản bạn cài nếu lỗi.
    device = cfg_ocr.get("device")  # vd. "gpu:0" | "cpu" | None (mặc định — để PaddleOCR tự
    # chọn theo bản paddlepaddle đã cài, CPU hay GPU). Máy cá nhân/Kaggle thường để trống (None);
    # modal_ocr_encode.py tự ép "gpu:0" khi chạy trên GPU thuê Modal, không cần sửa file này.
    kwargs = {"lang": lang}
    if ocr_version:
        kwargs["ocr_version"] = ocr_version
    if device:
        kwargs["device"] = device
    try:
        reader = PaddleOCR(use_angle_cls=True, **kwargs)
    except TypeError:
        # Một số bản paddleocr (API "PaddleX-style" mới hơn) không nhận use_angle_cls nữa.
        reader = PaddleOCR(**kwargs)
    print(
        f"[OCR] Dùng engine chính: PaddleOCR (lang={lang}, ocr_version={ocr_version or 'mặc định'}, "
        f"device={device or 'tự động'})"
    )

    def run(image_path: str):
        return _run_and_parse_paddleocr(reader, image_path)

    return run


def _run_and_parse_paddleocr(reader, image_path: str):
    """PaddleOCR đổi API surface giữa các phiên bản (2.x dùng `.ocr()`, bản mới hơn
    dùng `.predict()`); thử cả hai và chuẩn hoá về cùng 1 dạng
    [(bbox_4points, text, score), ...] để phần còn lại của file không phụ thuộc phiên bản.
    Nếu cả 2 cách đều lỗi/parse sai, sửa hàm này theo đúng output thực tế của bản bạn cài
    (in `result` ra xem cấu trúc, rồi chỉnh lại phần parse bên dưới)."""
    if hasattr(reader, "predict"):
        try:
            result = reader.predict(image_path)
            return _parse_predict_result(result)
        except Exception:
            pass  # rơi xuống thử .ocr() bên dưới

    if hasattr(reader, "ocr"):
        try:
            result = reader.ocr(image_path, cls=True)
        except TypeError:
            result = reader.ocr(image_path)
        return _parse_legacy_ocr_result(result)

    raise RuntimeError("Không tìm thấy method .predict()/.ocr() trên đối tượng PaddleOCR — kiểm tra lại bản cài.")


def _parse_legacy_ocr_result(result):
    """Dạng PaddleOCR 2.x: result = [[[box_points, (text, score)], ...]] (1 phần tử ngoài
    cùng mỗi ảnh)."""
    out = []
    if not result or result[0] is None:
        return out
    for box_points, (text, score) in result[0]:
        out.append((box_points, text, float(score)))
    return out


def _parse_predict_result(result):
    """Dạng PaddleOCR/PaddleX 3.x: result là list các dict (thường 1 phần tử/ảnh) với
    key kiểu 'rec_texts', 'rec_scores', 'rec_polys' hoặc 'dt_polys'. Tên key có thể khác
    giữa các bản — nếu KeyError, in `page.keys()` ra để chỉnh lại danh sách tên bên dưới."""
    out = []
    for page in result:
        data = page if isinstance(page, dict) else getattr(page, "json", None) or getattr(page, "__dict__", {})
        texts = data.get("rec_texts") or data.get("texts") or []
        scores = data.get("rec_scores") or data.get("scores") or []
        polys = data.get("rec_polys") or data.get("dt_polys") or data.get("polys") or []
        for box_points, text, score in zip(polys, texts, scores):
            out.append((box_points, text, float(score)))
    return out


def _make_easyocr_runner(languages: list):
    import easyocr
    import torch

    reader = easyocr.Reader(languages, gpu=torch.cuda.is_available())
    print(f"[OCR] Dùng engine fallback: EasyOCR (languages={languages})")

    def run(image_path: str):
        return reader.readtext(image_path)

    return run


# --------------------------------------------------------------------------- vietocr (recognizer phụ)

def load_vietocr_recognizer(cfg_ocr: dict):
    """Nạp VietOCR (pbcquoc/vietocr) làm recognizer PHỤ — CHỈ gọi lại cho box có confidence
    thấp từ engine chính (PaddleOCR/EasyOCR), không thay thế engine chính. VietOCR train
    chuyên cho tiếng Việt nên kỳ vọng đọc đúng dấu thanh/chữ hoa có dấu tốt hơn recognizer đa
    ngôn ngữ của PaddleOCR ở các trường hợp khó (đúng rủi ro "dấu tiếng Việt sai" — OCR.docx
    mục 9) — không dùng làm engine chính vì: (1) phải có box từ 1 detector khác rồi mới crop
    ra để đọc, thêm 1 lần suy luận/box thay vì 1 lần/ảnh như pipeline end-to-end, (2) yếu hơn
    engine đa ngôn ngữ với chữ không phải tiếng Việt (tên thương hiệu, phụ đề tiếng Anh).

    Trả về None nếu bị tắt trong config hoặc không nạp được (thiếu package/weight) — pipeline
    vẫn chạy bình thường chỉ với engine chính, giống triết lý primary/fallback ở trên (không
    để thiếu 1 package phụ làm hỏng cả lượt OCR)."""
    vcfg = cfg_ocr.get("vietocr", {}) or {}
    if not vcfg.get("enabled", True):
        return None

    try:
        from PIL import Image
        from vietocr.tool.config import Cfg
        from vietocr.tool.predictor import Predictor
    except Exception as e:
        print(f"[OCR] Không nạp được VietOCR ({e}) — bỏ qua recognizer phụ, chỉ dùng engine chính.")
        return None

    weight_name = vcfg.get("weight_name", "vgg_transformer")  # "vgg_transformer" (mặc định,
    # chính xác hơn) | "vgg_seq2seq" (nhẹ hơn, nhanh hơn trên CPU)
    try:
        config = Cfg.load_config_from_name(weight_name)
        config["device"] = "cuda:0" if vcfg.get("use_gpu", False) else "cpu"
        config["predictor"]["beamsearch"] = vcfg.get("beamsearch", False)
        predictor = Predictor(config)
    except Exception as e:
        print(f"[OCR] Không khởi tạo được VietOCR ({e}) — bỏ qua recognizer phụ, chỉ dùng engine chính.")
        return None

    print(
        f"[OCR] Đã nạp VietOCR ({weight_name}, device={config['device']}) làm recognizer phụ "
        f"cho box có confidence < {vcfg.get('trigger_confidence', 0.7)}."
    )

    def recognize(image_path: str, bbox: list):
        """bbox = [x, y, w, h] (đã tính bằng _bbox_from_points) -> (text, score) hoặc
        (None, 0.0) nếu crop rỗng/lỗi. Dùng crop hình chữ nhật thẳng trục (không perspective
        warp) — đơn giản, đủ dùng cho hầu hết lower-third/tiêu đề/phụ đề; chữ nghiêng/cong
        mạnh vẫn nên qua nhánh DeepSolo–PARSeq (chưa cài đặt, xem README) nếu cần chính xác
        hơn nữa."""
        x, y, w, h = bbox
        if w <= 0 or h <= 0:
            return None, 0.0
        try:
            img = Image.open(image_path).convert("RGB")
            crop = img.crop((max(0, x), max(0, y), x + w, y + h))
            if crop.width < 4 or crop.height < 4:
                return None, 0.0
            text, prob = predictor.predict(crop, return_prob=True)
        except Exception as e:
            print(f"[OCR][VietOCR] Lỗi nhận dạng lại box {bbox}: {e}")
            return None, 0.0
        return text, float(prob)

    return recognize


# --------------------------------------------------------------------------- extraction

def _bbox_from_points(box_points) -> list:
    xs = [p[0] for p in box_points]
    ys = [p[1] for p in box_points]
    x, y = min(xs), min(ys)
    w, h = max(xs) - x, max(ys) - y
    return [round(float(x), 1), round(float(y), 1), round(float(w), 1), round(float(h), 1)]


def run_ocr_for_video(
    video_id: str,
    keyframe_dir: str,
    run_engine,
    engine_name: str,
    cfg_ocr: dict,
    vietocr_recognize=None,
) -> list:
    frame_index_path = Path(keyframe_dir) / video_id / "frame_index.json"
    with open(frame_index_path, "r", encoding="utf-8") as f:
        frame_index = json.load(f)

    min_confidence = cfg_ocr.get("min_confidence", 0.4)
    ngram_size = cfg_ocr.get("char_ngram_size", 3)
    vietocr_trigger = (cfg_ocr.get("vietocr", {}) or {}).get("trigger_confidence", 0.7)
    run_at = datetime.now(timezone.utc).isoformat()
    n_vietocr_used = 0

    video_dir = Path(keyframe_dir) / video_id

    records = []
    for frame in tqdm(frame_index, desc=f"OCR {video_id}"):
        # Dựng lại đường dẫn ảnh từ frame_id + keyframe_dir THAY VÌ dùng thẳng frame["path"] —
        # "path" trong frame_index.json là đường dẫn TUYỆT ĐỐI ghi lại lúc trích keyframe trên
        # 1 máy cụ thể (có thể kiểu Windows nếu trích trên máy Windows của thành viên khác, hoặc
        # trỏ sai thư mục nếu chạy OCR trên máy/container khác máy đã trích keyframe — vd. Modal,
        # xem modal_ocr_encode.py). Cùng cách làm với modal_semantic_encode.py::encode_video.
        img_path = video_dir / f"frame_{frame['frame_id']:06d}.jpg"
        try:
            detections = run_engine(str(img_path))
        except Exception as e:
            print(f"[OCR] Lỗi ở frame {frame['frame_id']}: {e}")
            continue

        for box_points, text, score in detections:
            if score < min_confidence or not text.strip():
                continue
            bbox = _bbox_from_points(box_points)
            recognizer_used = engine_name

            # Box "khó" (qua được min_confidence nhưng vẫn thấp) -> cho VietOCR đọc lại crop,
            # chỉ giữ nếu VietOCR tự tin hơn kết quả engine chính (xem load_vietocr_recognizer).
            if vietocr_recognize is not None and score < vietocr_trigger:
                vt_text, vt_score = vietocr_recognize(str(img_path), bbox)
                if vt_text and vt_text.strip() and vt_score > score:
                    text, score = vt_text, vt_score
                    recognizer_used = "vietocr"
                    n_vietocr_used += 1

            fields = enrich_text_fields(text.strip(), ngram_size)
            records.append({
                "video_id": video_id,
                "frame_id": frame["frame_id"],
                "timestamp": frame["timestamp"],
                **fields,
                "geometry": {"bbox": bbox, "score": round(float(score), 3)},
                "provenance": {
                    "engine": engine_name,
                    "recognizer": recognizer_used,
                    "model": cfg_ocr.get("paddleocr_version", engine_name),
                    "config": {"lang": cfg_ocr.get("lang"), "min_confidence": min_confidence},
                    "run_at": run_at,
                },
                "_frame_path": str(img_path),  # dùng cho verify_hard_frames, bỏ trước khi ghi file
            })

    if vietocr_recognize is not None:
        print(f"[OCR] VietOCR đọc lại và thắng {n_vietocr_used} box confidence thấp trên {video_id}.")

    records.sort(key=lambda r: r["frame_id"])

    # Đánh dấu nghi ngờ ticker/logo cố định vị trí (mục 9) — PHẢI chạy trên record gốc theo
    # từng frame (trước merge_temporal), vì tỉ lệ count/total_frames chỉ đúng khi so trên
    # đơn vị "1 record = 1 lần xuất hiện ở 1 frame". Nếu chạy sau merge_temporal, mỗi nhóm
    # đã gộp nhiều frame thành 1 record duy nhất -> đếm sai (đếm số record gộp thay vì số
    # frame), khiến overlay xuất hiện ở gần như toàn bộ video vẫn không bị flag đúng.
    records = flag_static_overlays(
        records,
        total_frames=len(frame_index),
        min_ratio=cfg_ocr.get("static_overlay_ratio", 0.6),
    )

    # Hậu xử lý thời gian (mục 5.2): gộp box lặp qua vài frame liên tiếp bằng
    # confidence-weighted voting -> giảm nhiễu do motion blur/OCR sai ở 1 frame đơn lẻ.
    # merge_temporal giữ nguyên các field khác (kể cả likely_static_overlay) từ record đại
    # diện (best_rec / rec đơn lẻ) nên cờ overlay vẫn đúng sau khi gộp.
    records = merge_temporal(
        records,
        window=cfg_ocr.get("temporal_window", 5),
        iou_threshold=cfg_ocr.get("iou_merge_threshold", 0.5),
    )

    # Xác minh lần 2 cho record confidence thấp (mục 5.3) — mặc định NullVerifier,
    # chỉ đánh dấu needs_verification, không tự gọi API nào (xem verify_hard_frames.py).
    records = apply_verification(
        records,
        verifier=NullVerifier(),
        confidence_threshold=cfg_ocr.get("verify_confidence_threshold", 0.5),
    )

    for rec in records:
        rec.pop("_frame_path", None)

    return records


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/pipeline_config.yaml")
    parser.add_argument("--video_id", required=True)
    args = parser.parse_args()

    cfg = load_config(args.config)
    cfg_ocr = cfg["ocr"]
    engine_name, run_engine = load_ocr_engine(cfg_ocr)
    vietocr_recognize = load_vietocr_recognizer(cfg_ocr)

    results = run_ocr_for_video(
        args.video_id, cfg["paths"]["keyframes"], run_engine, engine_name, cfg_ocr, vietocr_recognize,
    )

    out_dir = Path(cfg["paths"]["ocr_text"])
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{args.video_id}.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

    n_flagged = sum(1 for r in results if r.get("needs_verification"))
    print(f"[{args.video_id}] {len(results)} đoạn text OCR ({engine_name}), {n_flagged} cần xác minh -> {out_path}")


if __name__ == "__main__":
    main()
