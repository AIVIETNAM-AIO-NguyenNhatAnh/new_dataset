# Module: OCR

**Việc chính:** phát hiện và đọc chữ xuất hiện trong keyframe (tiêu đề, phụ đề, ticker, biển hiệu, nhãn sản phẩm...), làm nguồn cho Text Matching.

**Input:** keyframe trong `data/keyframes/`.

**Output:** `data/processed/ocr_text/{video_id}.json` — mỗi record gồm text ở 4 dạng (raw/normalized/no_accent/n-gram), geometry (bbox+confidence), temporal (khoảng frame đã gộp), cờ `likely_static_overlay` và `needs_verification`, `provenance`. Xem đặc tả đầy đủ ở docstring đầu `run_ocr.py` và `docs/pipeline.md`.

**Đã cài đặt — theo khuyến nghị của `OCR.docx`** (báo cáo nghiên cứu riêng, xem tóm tắt trong `docs/ocr_decision.md`):

- **Engine chính:** `PaddleOCR` (PP-OCRv6_medium) — 50 ngôn ngữ có tiếng Việt, tối ưu scene text. Fallback tự động sang `EasyOCR` nếu PaddleOCR chưa cài/tải được model (cùng kiểu primary/fallback với `indexing/audio_asr/run_asr.py`).
- **Hậu xử lý thời gian** (`temporal_merge.py`): gộp box lặp qua vài frame liên tiếp bằng confidence-weighted voting, và đánh dấu box nghi ngờ là ticker/logo cố định vị trí (`likely_static_overlay`) để loại khỏi index theo mặc định.
- **Chuẩn hoá text** (`text_normalize.py`): raw/normalized/no-accent/char-ngram — phục vụ 3 tầng truy hồi (exact phrase → BM25 có dấu → BM25 không dấu/n-gram) trong `search/text_matching/search.py`.
- **Xác minh lần 2** (`verify_hard_frames.py`): interface sẵn, mặc định `NullVerifier` (không gọi API nào) — chỉ đánh dấu record confidence thấp cần xác minh. Muốn xác minh thật, implement `BaseVerifier` (có khung mẫu `GeminiVerifier`).
- **Agent định tuyến** (`search/text_matching/ocr_intent.py`): heuristic rule-based (không phải LLM) tăng trọng số kênh text khi query có dấu hiệu cần đọc chữ trong hình.

**Chưa cài đặt trong baseline** (nêu trong `OCR.docx` nhưng cần thêm tài nguyên/API key riêng để chạy thật, không phù hợp baseline chạy ngay trên Kaggle):
- DeepSolo + PARSeq fine-tune tiếng Việt riêng — cách đội vô địch AIC 2025 (OpenCubee_1) dùng. Cần tự huấn luyện.
- HunyuanOCR-1.5 / Gemini làm verifier thật cho frame khó — cần trọng số model riêng hoặc API key, xem `verify_hard_frames.py` để cắm vào.

Dùng: `python indexing/ocr/run_ocr.py --video_id xxx` (phải chạy `indexing/keyframe_extraction.py` trước).

## Chạy trên GPU thuê qua Modal (quy mô toàn bộ dataset AIC)

`modal_ocr_encode.py` ở thư mục gốc repo — 2 pha giống hệt `modal_semantic_encode.py`, dùng
chung Volume `aic2026-keyframes` (tái dùng keyframe đã tải cho bước semantic nếu có, đỡ tải
trùng từ Drive) và mount thẳng module này vào container (không copy/duplicate logic). GPU mặc
định `L40S`. Xem docstring đầu `modal_ocr_encode.py` để biết cách dùng đầy đủ:

```bash
modal run modal_ocr_encode.py --drive-folder "Keyframe AIC"
```

## Recognizer phụ — VietOCR cho box confidence thấp

**OCR.docx không đề cập VietOCR** — báo cáo chỉ khuyến nghị PP-OCRv6 chạy end-to-end (vừa
detect vừa recognize trong 1 model). Đây là hướng bổ sung riêng, nhắm đúng rủi ro "dấu tiếng
Việt sai" nêu ở mục 9 báo cáo: PaddleOCR là model đa ngôn ngữ (50 ngôn ngữ trong 1 model) nên
với chữ tiếng Việt khó (dấu thanh, chữ hoa có dấu, font truyền hình) đôi khi kém chính xác hơn
1 model train chuyên cho tiếng Việt.

**Cách hoạt động (`ocr.vietocr` trong `pipeline_config.yaml`, mặc định `enabled: true`):**
PP-OCRv6/EasyOCR vẫn chạy như engine chính cho **toàn bộ** keyframe như trước — không đổi gì ở
tầng này. Chỉ với box có confidence qua được `min_confidence` nhưng vẫn dưới
`vietocr.trigger_confidence` (mặc định 0.7), pipeline crop đúng vùng box đó và cho VietOCR đọc
lại; nếu VietOCR tự tin hơn (`score` cao hơn) thì lấy kết quả VietOCR, ngược lại giữ nguyên kết
quả engine chính. Trường `provenance.recognizer` trong mỗi record ghi rõ text cuối cùng đến từ
đâu (`"paddleocr"` hay `"vietocr"`).

**Vì sao không thay hẳn recognizer chính bằng VietOCR:** (1) VietOCR không tự detect được vùng
chữ — vẫn cần 1 detector (PaddleOCR) tìm box trước rồi mới crop đưa vào, nên thay hẳn nghĩa là
gọi 2 model tuần tự cho MỌI box thay vì chỉ số ít box khó, chậm hơn đáng kể trên quy mô hàng
nghìn video/hàng trăm nghìn keyframe của AIC; (2) VietOCR train chuyên tiếng Việt nên yếu hơn
với chữ không phải tiếng Việt lẫn trong video (tên thương hiệu, phụ đề tiếng Anh) — PaddleOCR
đa ngôn ngữ vẫn cần làm engine chính cho trường hợp này.

Tắt hoàn toàn (chỉ dùng PaddleOCR/EasyOCR như trước): set `ocr.vietocr.enabled: false`. Nếu
chưa `pip install vietocr`, pipeline tự bỏ qua recognizer phụ và in cảnh báo, không crash.

**VietOCR có cần GPU không:** Không bắt buộc — VietOCR chạy CPU được (`ocr.vietocr.use_gpu:
false`, mặc định). Vì recognizer phụ này CHỈ chạy cho thiểu số box "khó" (confidence thấp), số
lần gọi thực tế ít hơn nhiều so với chạy VietOCR cho toàn bộ ảnh — CPU đủ dùng kể cả ở quy mô
AIC. Cân nhắc bật `use_gpu: true` (đổi `weight_name` giữ nguyên, chỉ cần máy có CUDA) nếu: (a)
đang chạy chung batch trên máy/GPU thuê đã bật sẵn cho PP-OCRv6 (`paddlepaddle-gpu`) — tận
dụng luôn GPU đang rảnh giữa các lần gọi PaddleOCR, hoặc (b) benchmark thực tế thấy CPU làm
chậm tổng thời gian OCR đáng kể (video có nhiều lower-third/phụ đề dày đặc, nhiều box rơi vào
diện "khó"). Không cần thuê riêng GPU chỉ để chạy VietOCR như đã làm với semantic embedding.

**Việc còn có thể làm thêm:**
- [ ] Benchmark nội bộ CER/WER + Phrase Recall@K trên dữ liệu AIC thật (OCR.docx mục 7-8) trước khi đổi model
- [ ] Benchmark riêng VietOCR vs PaddleOCR recognizer trên box confidence thấp thực tế (chưa đo — quyết định `trigger_confidence` hiện tại là ước lượng, không phải số đo được)
- [ ] Nếu đổi `keyframe_extraction.py` sang shot detection thật (TransNetV2), gộp OCR theo `shot_id` thay vì cửa sổ `frame_id` cố định trong `temporal_merge.py`
- [ ] Cắm verifier thật (HunyuanOCR-1.5 hoặc Gemini) nếu cần xác minh frame khó tự động thay vì chỉ gắn cờ
