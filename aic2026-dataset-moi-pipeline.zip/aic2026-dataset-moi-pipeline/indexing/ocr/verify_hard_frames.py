"""
Xác minh lần 2 cho box OCR khó — OCR.docx mục 5.3 ("Xác minh frame khó") và mục 7
bước "Fine-tune tiếng Việt" / bảng so sánh model (HunyuanOCR-1.5, Gemini OCR).

Baseline KHÔNG gọi API/model ngoài nào cả: HunyuanOCR-1.5 cần tự tải trọng số riêng
(chưa có trong repo), Gemini cần API key của bạn. `NullVerifier` chỉ đánh dấu
`needs_verification` theo ngưỡng confidence để bạn biết record nào ĐÁNG xác minh,
không tự sinh thêm text nào — pipeline vẫn chạy được end-to-end mà không cần API key.

Nguyên tắc quan trọng từ báo cáo (mục 5.3): "Kết quả VLM không được ghi đè mù quáng;
phải lưu cả hai giả thuyết và điểm tin cậy để truy vết." Vì vậy `apply_verification()`
LƯU THÊM giả thuyết mới vào field "verification", không ghi đè "raw_text"/"normalized_text".

Cắm verifier thật: implement 1 class kế thừa `BaseVerifier`, truyền instance đó vào
`apply_verification()` trong `run_ocr.py` (xem `GeminiVerifier` bên dưới làm khung mẫu —
đội AIO_Owlgorithms tại AIC 2025 dùng đúng cách này để xử lý frame khó [OCR.docx, mục 2]).
"""
from abc import ABC, abstractmethod
from typing import Optional


class BaseVerifier(ABC):
    @abstractmethod
    def verify(self, image_path: str, crop_bbox: list, current_text: str) -> Optional[dict]:
        """Trả {"text": str, "confidence": float, "model": str} nếu có giả thuyết mới,
        hoặc None nếu bỏ qua/không xác minh được."""
        raise NotImplementedError


class NullVerifier(BaseVerifier):
    """Mặc định của baseline — không gọi model nào."""

    def verify(self, image_path: str, crop_bbox: list, current_text: str):
        return None


class GeminiVerifier(BaseVerifier):
    """Khung mẫu minh hoạ cách cắm Gemini OCR làm bước xác minh lần 2.

    CHƯA implement đầy đủ (cần `pip install google-generativeai` + GOOGLE_API_KEY của bạn).
    Điền phần crop ảnh theo `crop_bbox` + gọi API + parse text trả về trong `verify()`.
    """

    def __init__(self, api_key: str, model: str = "gemini-2.5-flash"):
        self.api_key = api_key
        self.model = model

    def verify(self, image_path: str, crop_bbox: list, current_text: str):
        raise NotImplementedError(
            "Điền code gọi Gemini API ở đây: crop ảnh theo crop_bbox, gửi kèm prompt OCR, "
            "parse text trả về, rồi trả {'text': .., 'confidence': .., 'model': self.model}."
        )


def apply_verification(records: list, verifier: BaseVerifier, confidence_threshold: float) -> list:
    """Với mỗi record có score < confidence_threshold: đánh dấu needs_verification=True
    và gọi verifier.verify() để lấy thêm giả thuyết (không ghi đè text gốc)."""
    for rec in records:
        score = rec["geometry"]["score"]
        rec["needs_verification"] = score < confidence_threshold
        rec["verification"] = None
        if rec["needs_verification"]:
            result = verifier.verify(rec["_frame_path"], rec["geometry"]["bbox"], rec["raw_text"])
            if result:
                rec["verification"] = result
    return records
