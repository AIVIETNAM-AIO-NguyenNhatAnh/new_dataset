"""
Chuẩn hoá text OCR theo đặc tả dữ liệu trong OCR.docx (mục 6 — "Đặc tả dữ liệu và tìm kiếm").

raw_text          giữ nguyên, không sửa — phục vụ kiểm tra/audit.
normalized_text   Unicode NFC, viết thường, chuẩn hoá khoảng trắng/dấu câu.
no_accent_text    bỏ dấu tiếng Việt — tăng recall khi người dùng gõ không dấu.
char_ngrams       n-gram ký tự — phục vụ fuzzy search khi OCR sai 1-2 ký tự.
"""
import re
import unicodedata

_WS_RE = re.compile(r"\s+")
_PUNCT_RE = re.compile(r"[^\w\s]", re.UNICODE)


def normalize_text(text: str) -> str:
    text = unicodedata.normalize("NFC", text)
    text = text.lower()
    text = _PUNCT_RE.sub(" ", text)
    text = _WS_RE.sub(" ", text).strip()
    return text


def strip_accents(text: str) -> str:
    """Bỏ dấu tiếng Việt. Xử lý riêng đ/Đ vì Unicode NFD không tách được ký tự này
    thành chữ cái nền + dấu (nó là 1 code point riêng, không phải o/e/... + combining mark)."""
    text = text.replace("đ", "d").replace("Đ", "D")
    decomposed = unicodedata.normalize("NFD", text)
    return "".join(c for c in decomposed if unicodedata.category(c) != "Mn")


def no_accent_text(text: str) -> str:
    return strip_accents(normalize_text(text))


def char_ngrams(text: str, n: int = 3) -> list:
    """N-gram ký tự trên bản đã chuẩn hoá (không dấu cách), dùng cho fuzzy match.
    Text ngắn hơn n ký tự trả về nguyên chuỗi làm 1 "gram" duy nhất thay vì rỗng,
    để không mất hẳn khả năng match với text rất ngắn (biển số, mã sản phẩm...)."""
    compact = normalize_text(text).replace(" ", "")
    if not compact:
        return []
    if len(compact) < n:
        return [compact]
    return [compact[i : i + n] for i in range(len(compact) - n + 1)]


def enrich_text_fields(raw_text: str, ngram_size: int = 3) -> dict:
    """Trả đủ 4 field text theo đặc tả OCR.docx mục 6, tính 1 lần cho mỗi record."""
    normalized = normalize_text(raw_text)
    return {
        "raw_text": raw_text,
        "normalized_text": normalized,
        "no_accent_text": strip_accents(normalized),
        "char_ngrams": char_ngrams(raw_text, ngram_size),
    }
