"""
Hậu xử lý thời gian cho kết quả OCR — OCR.docx mục 5.2 ("Hậu xử lý theo thời gian")
và mục 9 ("Rủi ro và biện pháp kiểm soát" — Ticker/logo gây nhiễu).

Cập nhật: `indexing/keyframe_extraction.py` giờ CHỈ còn 1 method "transnetv2_similarity" (Cách 5)
— shot detection THẬT bằng TransNetV2, đúng như OCR.docx mô tả (method "uniform" lấy đều N
giây/frame đã bị gỡ bỏ hoàn toàn khỏi repo). Mỗi keyframe trong `frame_index.json` giờ LUÔN có
sẵn `shot_id` thật. Hàm `merge_temporal` dưới đây HIỆN VẪN gộp theo cửa sổ VỊ TRÍ trong danh
sách (không dùng `shot_id`) — đây là xấp xỉ hợp lý để gộp box lặp (phụ đề/lower-third thường
đứng yên qua nhiều frame liên tiếp), nhưng KHÔNG tương đương gộp đúng theo shot thật (2 frame
liền kề trong list có thể thuộc 2 shot khác nhau). Nếu cần chính xác hơn, có thể sửa lại để
group theo `shot_id` thay vì cửa sổ vị trí cố định — chưa làm vì đây là thay đổi thuật toán,
cần cân nhắc/test riêng, không nằm trong phạm vi việc gỡ bỏ method "uniform".

QUAN TRỌNG: `window` so theo VỊ TRÍ TRONG LIST (số keyframe liên tiếp đã lấy mẫu), không
phải hiệu số `frame_id`. Vì `frame_id` là vị trí frame thật trong video gốc (đúng định nghĩa
của BTC — xem ghi chú đầu `indexing/keyframe_extraction.py`), 2 keyframe liên tiếp trong danh
sách có thể cách nhau rất khác nhau về đơn vị `frame_id` (Cách 5 tự thích nghi theo nội dung,
không phải khoảng cố định), nên không thể dùng hiệu số `frame_id` làm cửa sổ N frame liên tiếp
— phải dùng hiệu vị trí (index) trong list.
"""
from collections import defaultdict


def _iou(box_a, box_b):
    """IoU của 2 bbox dạng [x, y, w, h]."""
    ax, ay, aw, ah = box_a
    bx, by, bw, bh = box_b
    ax2, ay2 = ax + aw, ay + ah
    bx2, by2 = bx + bw, by + bh

    inter_x1, inter_y1 = max(ax, bx), max(ay, by)
    inter_x2, inter_y2 = min(ax2, bx2), min(ay2, by2)
    inter_w, inter_h = max(0.0, inter_x2 - inter_x1), max(0.0, inter_y2 - inter_y1)
    inter = inter_w * inter_h

    union = aw * ah + bw * bh - inter
    return inter / union if union > 0 else 0.0


def merge_temporal(records: list, window: int = 5, iou_threshold: float = 0.5) -> list:
    """Gộp các box có vị trí tương tự trong `window` KEYFRAME liên tiếp (theo vị trí trong
    list, không phải hiệu số frame_id — xem ghi chú đầu file) bằng confidence-weighted
    voting (OCR.docx mục 5.2: "Dùng confidence-weighted voting để chọn ký tự hoặc từ ổn
    định nhất").

    `records` phải đã sort theo frame_id (= vị trí frame thật trong video gốc) tăng dần,
    mỗi record có "frame_id", "timestamp", "raw_text" và "geometry": {"bbox":[x,y,w,h], "score":..}.
    """
    used = [False] * len(records)
    merged = []

    for i, rec in enumerate(records):
        if used[i]:
            continue
        group = [rec]
        used[i] = True
        for j in range(i + 1, len(records)):
            if used[j]:
                continue
            other = records[j]
            if j - i > window:
                break  # records đã sort theo thời gian -> có thể dừng sớm
            if _iou(rec["geometry"]["bbox"], other["geometry"]["bbox"]) >= iou_threshold:
                group.append(other)
                used[j] = True

        if len(group) == 1:
            out = dict(rec)
            out["temporal"] = {
                "frame_id_start": rec["frame_id"],
                "frame_id_end": rec["frame_id"],
                "timestamp_start": rec["timestamp"],
                "timestamp_end": rec["timestamp"],
                "frame_ids": [rec["frame_id"]],
                "n_merged": 1,
            }
            merged.append(out)
            continue

        # Confidence-weighted voting: chọn text có tổng confidence cao nhất trong nhóm,
        # rồi lấy record có score cao nhất trong số các record mang text đó làm đại diện.
        votes = defaultdict(float)
        for g in group:
            votes[g["raw_text"]] += g["geometry"]["score"]
        best_text = max(votes, key=votes.get)
        best_rec = max(
            (g for g in group if g["raw_text"] == best_text),
            key=lambda g: g["geometry"]["score"],
        )

        frame_ids = sorted(g["frame_id"] for g in group)
        timestamps = sorted(g["timestamp"] for g in group)
        out = dict(best_rec)
        out["temporal"] = {
            "frame_id_start": frame_ids[0],
            "frame_id_end": frame_ids[-1],
            "timestamp_start": timestamps[0],
            "timestamp_end": timestamps[-1],
            "frame_ids": frame_ids,
            "n_merged": len(group),
        }
        merged.append(out)

    return merged


def flag_static_overlays(records: list, total_frames: int, min_ratio: float = 0.6, iou_threshold: float = 0.7) -> list:
    """Đánh dấu `likely_static_overlay=True` cho box xuất hiện ở gần như cùng vị trí
    trong >= min_ratio số frame của video — dấu hiệu ticker/logo kênh cố định vị trí
    (OCR.docx mục 9: "Ticker/logo gây nhiễu: Phát hiện vùng cố định theo thời gian,
    đánh nhãn overlay và giảm trọng số").

    Đây là bước ước lượng theo VỊ TRÍ box, không theo nội dung chữ (ticker scroll nên
    nội dung đổi liên tục nhưng vùng chứa nó gần như cố định) — không thay thế
    `crop_box` thủ công nếu bạn biết chính xác toạ độ ticker của đài, nhưng dùng được
    khi chưa biết trước layout của nguồn video.

    O(n^2) theo số record của 1 video — đủ nhanh ở quy mô hàng trăm/vài nghìn record
    mỗi video của baseline; nếu video quá dài, cân nhắc tính theo từng cửa sổ thời gian
    thay vì toàn bộ record cùng lúc.
    """
    if total_frames == 0 or not records:
        return records

    for rec in records:
        box = rec["geometry"]["bbox"]
        count = sum(
            1 for other in records if _iou(box, other["geometry"]["bbox"]) >= iou_threshold
        )
        rec["likely_static_overlay"] = (count / total_frames) >= min_ratio

    return records
