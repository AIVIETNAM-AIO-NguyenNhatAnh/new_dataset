# Module: Audio / ASR

**Việc chính:** chuyển audio trong video thành văn bản (transcript) có timestamp, làm nguồn cho Text Matching (Meilisearch).

**Input:** video gốc trong `data/raw/` (tự tách audio bằng `extract_audio.py`, không cần chuẩn bị sẵn file wav).

**Output:** transcript (kèm timestamp, video_id) lưu vào `data/processed/transcripts/{video_id}.json`, format thống nhất:

```json
[{"start": 0.0, "end": 20.0, "text": "..."}]
```

Xem quy ước format tại `docs/pipeline.md`.

## 2 engine ASR

Chọn qua `configs/pipeline_config.yaml` -> `asr.engine`:

| Engine | Khi dùng | Cài đặt | Ghi chú |
|---|---|---|---|
| `transformers` (mặc định) | Kaggle, hoặc bất kỳ máy nào chưa cài whisper.cpp | `pip install transformers torchaudio torch` | Model chính `nguyenvulebinh/wav2vec2-base-vietnamese-250h`, fallback `openai/whisper-small`. Chia audio theo `chunk_length_s` (mặc định 20s), mỗi đoạn gọi `pipeline()` độc lập -> không giữ ngữ cảnh câu trước giữa các đoạn. |
| `whisper_cpp` | Máy local (Mac) hoặc máy/GPU thuê đã cài whisper.cpp | Xem bên dưới | Dùng binary `whisper-cli` + model ggml (vd. `ggml-small.bin`). Nếu không tìm thấy binary, code **tự động rơi về `transformers`** — để `engine: whisper_cpp` trong config trên Kaggle vẫn không làm hỏng pipeline. |

Cả 2 engine đều ghi ra cùng một format JSON thống nhất ở trên, nên phần index (`indexes/meilisearch/`) không cần biết engine nào đang chạy.

### Cài whisper.cpp cho engine `whisper_cpp`

```bash
# macOS
brew install whisper-cpp   # cài whisper-cli

# tải model ggml (vd. small)
bash models/download-ggml-model.sh small   # trong repo whisper.cpp, hoặc tải .bin thủ công
# đặt file .bin vào đường dẫn khai trong configs/pipeline_config.yaml -> asr.whisper_cpp.model_path
```

Nếu `binary: null` trong config, code tự tìm bằng `shutil.which("whisper-cli")`. Có thể set đường dẫn tuyệt đối nếu binary không nằm trong `PATH` (vd. `/opt/homebrew/bin/whisper-cli`).

**Thiết kế `-mc 0` (max-context=0):** tham khảo từ benchmark của nhóm trong `final/report.md` + `final/extract_audio_transcript.py` — mỗi đoạn audio whisper.cpp tự chia được decode độc lập, không mang ngữ cảnh câu trước sang đoạn sau, giúp giảm lặp câu/hallucination khi audio dài. Engine `whisper_cpp` còn xuất kèm `.srt/.vtt/.csv/.txt` (bên cạnh `.json` thống nhất) để xem lại nhanh hoặc dùng làm phụ đề.

## Cách chạy

```bash
python indexing/audio_asr/run_asr.py --video data/raw/L26_V200.mp4
```

## Việc cần làm

- [x] Script tách audio từ video (`extract_audio.py`)
- [x] Script chạy ASR trên audio, xuất transcript theo timestamp (`run_asr.py`, 2 engine)
- [ ] Đánh giá độ chính xác (WER) trên tập mẫu tiếng Việt — so sánh `transformers` vs `whisper_cpp` trên cùng video mẫu
- [x] Chuẩn hoá format output để `indexes/meilisearch/` đọc trực tiếp (`[{"start","end","text"}]`)
